# Market Desk — design

## 1. Architecture

```text
Analyst
  ↓
CopilotKit v2 provider + CopilotChat (@copilotkit/react-core/v2)
  ↓ streaming
CopilotRuntime + BuiltInAgent (@copilotkit/runtime/v2)
  ├─ query_market_data → defineTool → DuckDB read-only query surface → data/*.parquet
  └─ retrieve_policy    → defineTool → heading-aware search → docs/*.md
  ↓
Answer plus inline tool inputs, SQL, returned rows, retrieved excerpts, and filename/heading citations
```

The Next.js optional catch-all route serves the CopilotKit v2 multi-route runtime, including
`GET /api/copilotkit/info` and streamed agent requests. Both tools execute on the server through
`defineTool`; the OpenAI API key stays server-side. The chat renders each tool call's input and
result inline in the streamed conversation.

## 2. The two tools

**SQL:** DuckDB reads the provided Parquet files through four named views. The endpoint accepts one
`SELECT` or `WITH` statement, requires a reference to an allowlisted table, rejects write operations,
comments, external file/table functions, and multi-statements, interrupts queries after eight seconds,
and caps returned rows at 100. The UI shows the exact executed SQL and rows. No Parquet file is
modified.

**Retrieval:** I reviewed all six documents. They are short, already organized by clear Markdown
headings, and have stable filenames; enrichment with embeddings or a vector database is unnecessary.
The tool chunks at each heading, ranks lexical overlap with inverse document frequency, boosts
heading matches and adjacent query phrases, and returns up to four filename/heading/excerpt records.
This keeps evidence inspectable and avoids an embedding service. The main limitation is lower recall
for paraphrases and synonyms than a semantic retriever.

## 3. Grounding and trust

The system instructions require `query_market_data` for observed values, counts, dates, and
calculations; `retrieve_policy` for rules and operating assumptions; and both for mixed questions.
Exact table/column names, intervention filtering, citation format, and the FCAS limitation are
included in the instructions. Tool results—not model memory—are the intended source of figures.
The chat renders the tool input and result inline, including executed SQL, returned rows, and
retrieved policy sections; policy claims should cite `filename > heading`. Tool errors are surfaced
rather than replaced with plausible answers. The visible tool activity also makes missing evidence
visible; prompt instructions are not a cryptographic guarantee against model non-compliance.

## 4. As-of honesty

Forecast instructions require `RUN_DATETIME <= τ` and the maximum eligible run for each forecast
interval and region. The answer must state when there is no eligible run or when the short P5MIN
horizon cannot cover the requested future period. Predispatch is not in this sample.

## 5. Evaluation plan

`evaluation/questions.json` labels representative database, policy, mixed, and cannot-answer
questions with expected tools and observable behaviors. The automated tests verify the SQL allowlist,
write/external-scan rejection, row caps, and retrieval ranking for bid-price lock and FCAS limitation
questions. For a live evaluation, measure numeric agreement against independent DuckDB results,
citation precision (returned file and heading support the claim), correct as-of vintage selection,
and refusal accuracy on unsupported questions.

## 6. Failure modes

The weakest questions are policy paraphrases that share few words with the source, or compound
questions requiring multi-step commercial reasoning. Keyword retrieval can miss a synonym; the model
can also omit a tool despite its instructions. Check the visible evidence and treat absent sources as
an unresolved answer.

## 7. Run it

From the repository root, follow `app/README.md`: enter `track1_qna_copilotkit/app`, run `npm ci`,
copy `.env.example` to `.env.local`, set `OPENAI_API_KEY`, then run `npm run dev`.
