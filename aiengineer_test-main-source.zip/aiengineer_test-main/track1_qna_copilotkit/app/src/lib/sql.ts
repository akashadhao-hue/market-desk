import path from "node:path";
import { DuckDBInstance } from "@duckdb/node-api";

const TABLES = [
  "dispatchprice",
  "dispatchregionsum",
  "market_price_thresholds",
  "p5min_regionsolution",
] as const;
const MAX_SQL_LENGTH = 8_000;
const MAX_ROWS = 100;
const QUERY_TIMEOUT_MS = 8_000;
const BLOCKED_FUNCTIONS =
  /\b(?:read_[a-z0-9_]*|parquet_scan|glob|query|query_table|query_table_function|sqlite_scan|postgres_scan|http_get|load_extension)\s*\(/i;
const BLOCKED_OPERATIONS =
  /\b(?:insert|update|delete|merge|copy|create|drop|alter|attach|detach|install|load|pragma|call|export|import|vacuum|set|reset|truncate|grant|revoke)\b/i;

let instancePromise: Promise<DuckDBInstance> | undefined;

function getInstance(): Promise<DuckDBInstance> {
  instancePromise ??= DuckDBInstance.create(":memory:", {
    threads: "2",
    memory_limit: "256MB",
  });
  return instancePromise;
}

function parquetPath(fileName: string): string {
  const dataDirectory = path.resolve(process.cwd(), "../../data");
  return path.join(dataDirectory, fileName).replaceAll("'", "''");
}

export function validateSql(sql: string): string {
  const query = sql.trim();
  if (!query || query.length > MAX_SQL_LENGTH) {
    throw new Error(`SQL must be between 1 and ${MAX_SQL_LENGTH} characters.`);
  }
  if (/[;]|--|\/\*|\*\/|#/.test(query)) {
    throw new Error("Only a single uncommented SQL query is allowed.");
  }

  const withoutStrings = query.replace(/'(?:''|[^'])*'/g, "''");
  if (!/^(?:select|with)\b/i.test(withoutStrings)) {
    throw new Error("Only read-only SELECT queries are allowed.");
  }
  if (
    BLOCKED_OPERATIONS.test(withoutStrings) ||
    BLOCKED_FUNCTIONS.test(withoutStrings) ||
    /\b(?:from|join)\s+[a-z_][\w]*\s*\(/i.test(withoutStrings)
  ) {
    throw new Error("This query contains a blocked SQL operation or external data function.");
  }
  return query;
}

export async function executeSql(sql: string): Promise<{
  sql: string;
  rows: Record<string, unknown>[];
  rowCount: number;
  truncated: boolean;
}> {
  const query = validateSql(sql);
  const instance = await getInstance();
  const connection = await instance.connect();
  let timeout: ReturnType<typeof setTimeout> | undefined;

  try {
    const referencedTables = connection.getTableNames(query, false);
    if (
      referencedTables.length === 0 ||
      referencedTables.some(
        (table) => !TABLES.includes(table.toLowerCase() as (typeof TABLES)[number]),
      )
    ) {
      throw new Error("Queries must read at least one of the supplied Parquet tables.");
    }

    for (const table of TABLES) {
      const fileName = `${table}.parquet`;
      await connection.run(
        `CREATE OR REPLACE TEMP VIEW ${table} AS SELECT * FROM read_parquet('${parquetPath(fileName)}')`,
      );
    }

    const executedSql = `SELECT * FROM (${query}) AS bounded_result LIMIT ${MAX_ROWS}`;
    timeout = setTimeout(() => connection.interrupt(), QUERY_TIMEOUT_MS);
    const result = await connection.runAndReadAll(executedSql);
    const rows = result.getRowObjectsJson() as Record<string, unknown>[];
    return {
      sql: executedSql,
      rows,
      rowCount: rows.length,
      truncated: rows.length === MAX_ROWS,
    };
  } finally {
    if (timeout) clearTimeout(timeout);
    connection.disconnectSync();
  }
}
