import {
  BuiltInAgent,
  CopilotRuntime,
  createCopilotRuntimeHandler,
  defineTool,
} from "@copilotkit/runtime/v2";
import { z } from "zod";
import { retrievePolicy } from "./retrieval";
import { executeSql } from "./sql";

const tools = [
  defineTool({
    name: "query_market_data",
    description:
      "Run a read-only DuckDB SELECT query against the four supplied market Parquet tables. Use for exact market values and calculations. Returns the executed SQL and rows.",
    parameters: z.object({
      sql: z
        .string()
        .min(1)
        .max(8_000)
        .describe(
          "One SELECT or WITH query using dispatchprice, dispatchregionsum, market_price_thresholds, or p5min_regionsolution.",
        ),
    }),
    execute: ({ sql }) => executeSql(sql),
  }),
  defineTool({
    name: "retrieve_policy",
    description:
      "Search the six internal policy Markdown documents for rules, operating assumptions, and limitations. Cite the returned filename and heading.",
    parameters: z.object({
      question: z.string().min(1).max(2_000).describe("The policy question or terms to search for."),
    }),
    execute: async ({ question }) => ({ sections: await retrievePolicy(question) }),
  }),
];

const prompt = `You are a trustworthy assistant for Australian NEM market data and internal policy.
For every answer about market observations or exact values, call query_market_data before answering. Never invent or recall a data number. Query only these tables and columns:
- dispatchprice(SETTLEMENTDATE, REGIONID, INTERVENTION, RRP, APCFLAG, MARKETSUSPENDEDFLAG, PRICE_STATUS)
- dispatchregionsum(SETTLEMENTDATE, REGIONID, INTERVENTION, TOTALDEMAND, AVAILABLEGENERATION, NETINTERCHANGE, SS_SOLAR_UIGF, SS_WIND_UIGF)
- market_price_thresholds(EFFECTIVEDATE, VERSIONNO, VOLL, MARKETPRICEFLOOR, ADMINISTERED_PRICE_THRESHOLD, AUTHORISEDDATE, LASTCHANGED)
- p5min_regionsolution(RUN_DATETIME, INTERVAL_DATETIME, REGIONID, INTERVENTION, RRP)
Filter INTERVENTION = 0 where the column exists. Timestamps are AEMO time (UTC+10) and interval-ending. The tool returns the exact executed SQL and at most 100 rows.
Use retrieve_policy for policy, rules, operating assumptions, and limitations; cite every policy claim using the returned filename and heading. For mixed questions, use both tools.
Forecasts are versioned: for a forecast as of decision time τ, require RUN_DATETIME <= τ and select the maximum eligible RUN_DATETIME per forecast interval and region. Explain when the available P5MIN horizon cannot answer the requested horizon.
The supplied sample is energy-only and has no FCAS data. State that FCAS revenue cannot be answered from this dataset; do not estimate it.
If tools return no relevant evidence or fail, say so plainly. Do not present unsupported numbers. Separate computed findings from policy interpretation.`;

const runtime = new CopilotRuntime({
  agents: {
    default: new BuiltInAgent({
      model: `openai/${process.env.OPENAI_MODEL ?? "gpt-4o-mini"}`,
      prompt,
      tools,
      maxSteps: 4,
    }),
  },
});

export const copilotHandler = createCopilotRuntimeHandler({
  runtime,
  basePath: "/api/copilotkit",
});
