import assert from "node:assert/strict";
import test from "node:test";
import { executeSql, validateSql } from "./sql";

test("accepts a bounded SELECT using a supplied table", () => {
  assert.equal(
    validateSql("SELECT REGIONID, RRP FROM dispatchprice WHERE REGIONID = 'NSW1'"),
    "SELECT REGIONID, RRP FROM dispatchprice WHERE REGIONID = 'NSW1'",
  );
});

test("rejects write statements, comments, multiple statements, and external scans", () => {
  for (const sql of [
    "DELETE FROM dispatchprice",
    "SELECT * FROM dispatchprice; DROP TABLE dispatchprice",
    "SELECT * FROM dispatchprice -- hidden clause",
    "SELECT * FROM read_parquet('data/dispatchprice.parquet')",
    "SELECT * FROM dispatchprice WHERE REGIONID = 'NSW1' UNION ALL SELECT * FROM read_csv_auto('x')",
  ]) {
    assert.throws(() => validateSql(sql));
  }
});

test("queries only rows from the supplied Parquet tables and returns bounded results", async () => {
  const result = await executeSql(
    "SELECT COUNT(*) AS row_count FROM dispatchprice WHERE REGIONID = 'NSW1' AND INTERVENTION = 0",
  );
  assert.equal(result.rowCount, 1);
  assert.equal(result.rows[0].row_count, "26784");
  assert.match(result.sql, /LIMIT 100$/);
});

test("rejects queries that do not reference the supplied dataset", async () => {
  await assert.rejects(() => executeSql("SELECT 1 AS unsupported"));
  await assert.rejects(() => executeSql("SELECT * FROM range(10)"));
});
