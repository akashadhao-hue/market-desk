import assert from "node:assert/strict";
import test from "node:test";
import { retrievePolicy } from "./retrieval";

test("retrieves a bid-price lock section with stable filename and heading", async () => {
  const results = await retrievePolicy("Can we change bid prices during the trading day?");
  assert.ok(results.length > 0);
  assert.equal(results[0].file, "02_bidding_rules.md");
  assert.equal(results[0].heading, "The daily price lock");
  assert.match(results[0].excerpt, /fixed for the whole trading day/i);
});

test("retrieves FCAS limitation evidence from the policy corpus", async () => {
  const results = await retrievePolicy("Does the market data include FCAS revenue?");
  assert.ok(results.some((section) => /no FCAS|energy-only/i.test(section.excerpt)));
});

test("caps the number of returned sections", async () => {
  const results = await retrievePolicy("prices rules battery forecast market", 100);
  assert.ok(results.length <= 6);
});
