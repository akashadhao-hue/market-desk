import { readFile } from "node:fs/promises";
import path from "node:path";

export interface PolicySection {
  file: string;
  heading: string;
  excerpt: string;
  score: number;
}

const STOP_WORDS = new Set([
  "a",
  "an",
  "and",
  "are",
  "as",
  "at",
  "be",
  "can",
  "do",
  "does",
  "for",
  "from",
  "how",
  "i",
  "in",
  "is",
  "it",
  "me",
  "of",
  "on",
  "our",
  "the",
  "to",
  "was",
  "we",
  "what",
  "when",
  "where",
  "which",
  "who",
  "why",
  "with",
]);

function tokenize(value: string): string[] {
  const tokens = value.toLowerCase().match(/[a-z0-9]+/g);
  return (
    tokens
      ?.map((token) => (token.length > 4 && token.endsWith("s") ? token.slice(0, -1) : token))
      .filter((token) => token.length > 1 && !STOP_WORDS.has(token)) ?? []
  );
}

function parseSections(file: string, text: string): PolicySection[] {
  const sections: PolicySection[] = [];
  let heading = file.replace(/^\d+_/, "").replace(/\.md$/, "").replaceAll("_", " ");
  let body: string[] = [];

  const save = () => {
    const excerpt = body.join("\n").trim();
    if (excerpt) sections.push({ file, heading, excerpt, score: 0 });
  };

  for (const line of text.split(/\r?\n/)) {
    const headingMatch = /^(#{1,3})\s+(.+?)\s*#*\s*$/.exec(line);
    if (headingMatch) {
      save();
      heading = headingMatch[2];
      body = [];
    } else {
      body.push(line);
    }
  }
  save();
  return sections;
}

async function loadSections(): Promise<PolicySection[]> {
  const docsDirectory = path.resolve(process.cwd(), "../../docs");
  const fileNames = [
    "01_market_overview.md",
    "02_bidding_rules.md",
    "03_battery_operations.md",
    "04_forecasts.md",
    "05_price_caps_normalisation.md",
    "06_data_governance.md",
  ];

  const allSections = await Promise.all(
    fileNames.map(async (file) => {
      const content = await readFile(path.join(docsDirectory, file), "utf8");
      return parseSections(file, content);
    }),
  );
  return allSections.flat();
}

export async function retrievePolicy(
  question: string,
  limit = 4,
): Promise<PolicySection[]> {
  const queryTerms = [...new Set(tokenize(question))];
  if (queryTerms.length === 0) return [];

  const sections = await loadSections();
  const prepared = sections.map((section) => ({
    section,
    headingTerms: new Set(tokenize(section.heading)),
    contentTerms: new Set(tokenize(section.excerpt)),
  }));
  const queryTokens = question.toLowerCase().match(/[a-z0-9]+/g) ?? [];
  const queryPhrases = queryTokens.slice(1).map((token, index) => {
    const previous = queryTokens[index];
    return previous && !STOP_WORDS.has(previous) && !STOP_WORDS.has(token)
      ? `${previous} ${token}`
      : "";
  });
  const documentFrequency = new Map(
    queryTerms.map((term) => [
      term,
      prepared.filter(
        ({ headingTerms, contentTerms }) =>
          headingTerms.has(term) || contentTerms.has(term),
      ).length,
    ]),
  );

  return prepared
    .map(({ section, headingTerms, contentTerms }) => {
      let score = 0;
      for (const term of queryTerms) {
        const frequency = documentFrequency.get(term) ?? 0;
        const inverseFrequency = Math.log1p(sections.length / (frequency + 1));
        const termWeight = frequency <= 2 ? 3 : 1;
        if (headingTerms.has(term)) score += inverseFrequency * 4 * termWeight;
        if (contentTerms.has(term)) score += inverseFrequency * termWeight;
      }
      const sourceText = `${section.heading}\n${section.excerpt}`.toLowerCase();
      score += queryPhrases.filter((phrase) => phrase && sourceText.includes(phrase)).length * 5;
      if (section.excerpt.toLowerCase().includes(question.trim().toLowerCase())) {
        score += 4;
      }
      return { ...section, score };
    })
    .filter((section) => section.score > 0)
    .sort(
      (left, right) =>
        right.score - left.score ||
        left.file.localeCompare(right.file) ||
        left.heading.localeCompare(right.heading),
    )
    .slice(0, Math.min(Math.max(limit, 1), 6))
    .map((section) => ({
      ...section,
      excerpt:
        section.excerpt.length > 2_400
          ? `${section.excerpt.slice(0, 2_400)}…`
          : section.excerpt,
    }));
}
