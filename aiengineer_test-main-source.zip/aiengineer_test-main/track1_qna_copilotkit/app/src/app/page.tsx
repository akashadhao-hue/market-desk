import MarketAssistant from "./MarketAssistant";

export default function Home() {
  return <MarketAssistant />;
}
