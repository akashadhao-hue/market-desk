"use client";

import Link from "next/link";
import { CopilotChat, useRenderTool } from "@copilotkit/react-core/v2";
import { z } from "zod";

function formatToolResult(result: string | undefined): string {
  if (!result) return "Waiting for the tool result…";
  try {
    return JSON.stringify(JSON.parse(result), null, 2);
  } catch {
    return result;
  }
}

function ToolCallEvidence({
  label,
  status,
  input,
  result,
}: {
  label: string;
  status: string;
  input: string | undefined;
  result: string | undefined;
}) {
  const statusLabel =
    status === "complete" ? "COMPLETE" : status === "executing" ? "RUNNING" : "QUEUED";

  return (
    <details className="tool-evidence" open>
      <summary>
        <span className="tool-evidence-label">{label}</span>
        <span className="tool-evidence-status">{statusLabel}</span>
      </summary>
      <div className="tool-evidence-block">
        <span>INPUT</span>
        <pre>{input ?? ""}</pre>
      </div>
      {status === "complete" && (
        <div className="tool-evidence-block">
          <span>RESULT</span>
          <pre>{formatToolResult(result)}</pre>
        </div>
      )}
    </details>
  );
}

export default function MarketAssistant() {
  useRenderTool({
    name: "query_market_data",
    parameters: z.object({ sql: z.string() }),
    render: ({ status, parameters, result }) => (
      <ToolCallEvidence
        label="DuckDB query"
        status={status}
        input={parameters.sql}
        result={result}
      />
    ),
  });

  useRenderTool({
    name: "retrieve_policy",
    parameters: z.object({ question: z.string() }),
    render: ({ status, parameters, result }) => (
      <ToolCallEvidence
        label="Policy retrieval"
        status={status}
        input={parameters.question}
        result={result}
      />
    ),
  });

  return (
    <main className="workspace">
      <header className="topbar">
        <Link className="brand" href="/" aria-label="Market Desk home">
          <span className="brand-mark">M</span>
          <span>Market Desk</span>
        </Link>
        <span className="dataset-badge">
          <span className="status-dot" />
          2024 NEM sample · 5 regions
        </span>
      </header>

      <section className="intro">
        <p className="eyebrow">MARKET INTELLIGENCE</p>
        <h1>Ask the market anything.</h1>
        <p className="intro-copy">
          Grounded answers from AEMO market data and the operations policy corpus.
          SQL and retrieved document sections appear inline with each answer.
        </p>
      </section>

      <section className="desk-grid" aria-label="Market Q&A workspace">
        <div className="chat-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">ASSISTANT</p>
              <h2>Market Q&amp;A</h2>
            </div>
            <span className="live-tag">TOOLS ENABLED</span>
          </div>
          <div className="chat-shell">
            <CopilotChat
              agentId="default"
              labels={{
                modalHeaderTitle: "Market Q&A",
                welcomeMessageText: "Start with a data, policy, or mixed question.",
                chatInputPlaceholder: "Ask about prices, forecasts, or policy…",
              }}
            />
          </div>
        </div>
      </section>

      <footer className="page-footer">
        Data sample: AEMO NEMweb MMSDM · Jan, May &amp; Aug 2024 · timestamps AEMO time (UTC+10)
      </footer>
    </main>
  );
}
