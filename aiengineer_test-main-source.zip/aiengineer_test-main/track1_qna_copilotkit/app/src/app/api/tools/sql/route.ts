import { NextResponse } from "next/server";
import { executeSql } from "@/lib/sql";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || !("sql" in body) || typeof body.sql !== "string") {
    return NextResponse.json({ error: "Provide SQL as a string." }, { status: 400 });
  }

  try {
    return NextResponse.json(await executeSql(body.sql));
  } catch (error) {
    const message = error instanceof Error ? error.message : "The SQL query failed.";
    const status = /only|must|blocked|allowed|characters|single/i.test(message) ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
