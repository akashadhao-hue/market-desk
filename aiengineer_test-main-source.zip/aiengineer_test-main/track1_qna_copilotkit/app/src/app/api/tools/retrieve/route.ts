import { NextResponse } from "next/server";
import { retrievePolicy } from "@/lib/retrieval";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || !("question" in body) || typeof body.question !== "string") {
    return NextResponse.json({ error: "Provide a question as a string." }, { status: 400 });
  }
  if (body.question.trim().length === 0 || body.question.length > 2_000) {
    return NextResponse.json(
      { error: "The question must be between 1 and 2,000 characters." },
      { status: 400 },
    );
  }

  try {
    return NextResponse.json({ sections: await retrievePolicy(body.question) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Policy retrieval failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
