import { copilotHandler } from "@/lib/copilotRuntime";

export const runtime = "nodejs";

export const GET = copilotHandler;
export const POST = copilotHandler;
export const PATCH = copilotHandler;
export const DELETE = copilotHandler;
