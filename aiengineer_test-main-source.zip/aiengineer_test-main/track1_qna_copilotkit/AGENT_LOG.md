# Agent log

## Decomposition

1. Scaffold the web application and confirm CopilotKit/DuckDB APIs.
2. Implement and test the read-only SQL route.
3. Implement and test document-section retrieval.
4. Wire both tools to the streaming chat and show evidence in the UI.
5. Document architecture, setup, evaluation, and verification.

## Work record

### App scaffold and dependency setup

- **Instruction:** Implement the approved Track 1 plan with CopilotKit React, a custom Next.js route,
  OpenAI, DuckDB, and policy retrieval.
- **Produced:** Created a Next.js app under `track1_qna_copilotkit/app` and added the required
  CopilotKit and DuckDB packages.
- **Verification:** Inspected installed package declarations; confirmed `DuckDBConnection` can run
  Parquet-backed views and `getTableNames` can inspect table references.
- **Correction:** Externalized DuckDB native bindings from the Next.js bundle and removed the
  scaffold's cache-components flags that conflicted with Node route handlers.

### SQL tool

- **Instruction:** Add guarded, read-only SQL access to the supplied Parquet tables with bounds.
- **Produced:** Added a Next.js API route and DuckDB layer that permits a single SELECT/WITH query
  against allowlisted views, rejects writes/comments/external scans, interrupts long queries, and
  caps output at 100 rows.
- **Verification:** Focused tests query NSW dispatch-price rows, assert the known row count, reject
  write/multi-statement/external-file queries, and reject queries without a data-table reference.
- **Correction:** DuckDB table-name inspection returns no names after a view is registered, so
  validation now inspects query references before creating the per-connection views.

### Policy retrieval and chat

- **Instruction:** Review the corpus before selecting retrieval and expose the source sections and
  SQL used by streaming answers.
- **Produced:** Added heading-aware lexical retrieval with inverse document frequency, heading
  weights, and phrase boosts; registered the SQL and retrieval functions as server-side CopilotKit
  v2 tools; and rendered each tool input and result inline with the streamed chat.
- **Verification:** Unit tests confirm the daily price-lock section ranks first for the bid-change
  question and the corpus returns the FCAS limitation for an FCAS question.
- **Correction:** Initial lexical ranking favored generic price/data sections; inverse document
  frequency and query phrase boosts improved the targeted section ordering.

### Runtime integration correction

- **Instruction:** Resolve the CopilotKit runtime-info request failure discovered in browser smoke
  testing.
- **Produced:** Replaced the legacy runtime endpoint with CopilotKit's v2 multi-route handler,
  mounted at an optional catch-all route, and moved tool execution to server-defined `defineTool`
  functions. The React v2 chat renders tool inputs, SQL, query rows, and retrieved policy sections
  inline.
- **Verification:** `GET /api/copilotkit/info` and the home page both returned HTTP 200 without an
  API key; the browser loaded the chat without runtime errors.
- **Correction:** The legacy single-route handler returned 404/405 for the v2 runtime-info path;
  the v2 multi-route handler serves `/info` and agent requests consistently.

### Documentation and final verification

- **Instruction:** Complete the design, run instructions, evaluation set, and task log.
- **Produced:** Added `DESIGN.md`, `app/README.md`, `.env.example`, and a labeled question set.
- **Verification:** `npm run lint`, `npm test` (7 tests), and `npm run build` passed. Live HTTP
  smoke tests returned HTTP 200 for `/`, `/api/copilotkit/info`, and the two tool routes. The SQL
  write attempt returned HTTP 400. A model-generated answer was not tested because no OpenAI API
  key was available.
- **Correction:** No credentials or external market data were added.
